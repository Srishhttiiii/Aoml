import re
from google.oauth2 import service_account
import google.auth
from config import api_key, video_id
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError

# Replace with your own values
API_SERVICE_NAME = "youtube"
API_VERSION = "v3"
API_KEY = api_key
VIDEO_ID = video_id
CREDENTIALS_FILE = "my_secret.json"

emoji_pattern = re.compile("["
                           u"\U0001F600-\U0001F64F"  # emoticons
                           u"\U0001F300-\U0001F5FF"  # symbols & pictographs
                           u"\U0001F680-\U0001F6FF"  # transport & map symbols
                           u"\U0001F1E0-\U0001F1FF"  # flags (iOS)
                           "]+", flags=re.UNICODE)

# Authenticate with the YouTube Data API
if API_KEY:
    youtube = build(API_SERVICE_NAME, API_VERSION, developerKey=API_KEY)
else:
    credentials = service_account.Credentials.from_service_account_file(
        CREDENTIALS_FILE,
        scopes=["https://www.googleapis.com/auth/youtube.force-ssl"]
    )
    youtube = build(API_SERVICE_NAME, API_VERSION, credentials=credentials)

try:
    # Get the top-level comments for the video
    comments = []
    results = youtube.commentThreads().list(
        part="snippet",
        videoId=VIDEO_ID,
        order="relevance",
        textFormat="plainText",
        maxResults=15
    ).execute()

    # Extract the comment text from each thread
    for item in results["items"]:
        comment = item["snippet"]["topLevelComment"]["snippet"]["textDisplay"]
        comments.append(emoji_pattern.sub("", comment))

    with open("../top_15_comments.txt", "w") as f:
        f.write("")
    
    with open("../top_15_comments.txt", "a") as f:
        for i, comment in enumerate(comments):
            try:
                f.write(f"{i+1}. {comment}" + "\n")
                print(f"{i+1}. {comment}")

            except UnicodeEncodeError:
                continue
except HttpError as e:
    print("An error occurred:", e)
