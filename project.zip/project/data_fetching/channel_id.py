import googleapiclient.discovery
from config import api_key
import googleapiclient.errors

DEVELOPER_KEY = api_key
YOUTUBE_API_SERVICE_NAME = "youtube"
YOUTUBE_API_VERSION = "v3"

def get_channel_id(video_id):
    youtube = googleapiclient.discovery.build(
        YOUTUBE_API_SERVICE_NAME, YOUTUBE_API_VERSION, developerKey=DEVELOPER_KEY)

    video_response = youtube.videos().list(
        id=video_id,
        part="snippet"
    ).execute()

    channel_id = video_response["items"][0]["snippet"]["channelId"]

    return channel_id

print(get_channel_id("6jZag81Tmhw"))