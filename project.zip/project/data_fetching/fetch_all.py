import re
import pandas as pd
from config import api_key, channel_id, channel_name
from googleapiclient.discovery import build

# constants
API_SERVICE_NAME = "youtube"
API_VERSION = "v3"
API_KEY = api_key
CREDENTIALS_FILE = "my_secret.json"
videos_to_fetch = 20
comments_to_fetch = 30

# put true if we want to fetch comments from a single channel only from all the videos
single_channel = False


# regex removal of emojis
emoji_pattern = re.compile("["
                           u"\U0001F600-\U0001F64F"  # emoticons
                           u"\U0001F300-\U0001F5FF"  # symbols & pictographs
                           u"\U0001F680-\U0001F6FF"  # transport & map symbols
                           u"\U0001F1E0-\U0001F1FF"  # flags (iOS)
                           "]+", flags=re.UNICODE)

if API_KEY:
    youtube = build(API_SERVICE_NAME, API_VERSION, developerKey=API_KEY)

df = pd.DataFrame(columns= ['team_name'] + ['video_id'] + [f'comment_{i}' for i in range(1, comments_to_fetch + 1)])

if single_channel:
    #api call
    channel_response = youtube.channels().list(
        part="contentDetails",
        id=channel_id
    ).execute()
    playlist_id = channel_response["items"][0]["contentDetails"]["relatedPlaylists"]["uploads"]
    playlist_ids = [playlist_id]
    team_name = channel_name
else:
    playlist_ids = ['PLx6bGx4zt6EmPriltuUixZVJGJxnVT3ZB', 'PLp_A7BZlpSOfgBj7VJcPr6zEwjiYnpTIV', 'PLM7o8Rfl9FTn4eRyi8z1n-ClT0wUGLp3b', 'PLR8DItC4f5xvJ8f3zMpgLfmVwQj0UNA9c', 'PLY8T1xH7hxoq6gCqVP-W2Y7LF-wgBNJWl', 'PL5-QUghxmluI1Ucw-a4GEVoHvObj1rKsS', 'PLkB7IpRClaTKicibijh_8VAP0JVQJHEfF']
    team_name = ['Chelsea', 'Manchester City', 'Southampton', 'Liverpool', 'Fulham', 'Manchester United', 'Everton']


for playlist_id, team_name in zip(playlist_ids, team_name):
    videos_response = youtube.playlistItems().list(
        part="snippet",
        playlistId=playlist_id,
        maxResults=videos_to_fetch
    ).execute()

    video_ids = []
    for video in videos_response["items"]:
        video_ids.append(video["snippet"]["resourceId"]["videoId"])


    for video_id in video_ids:
        try:
            comments = []
            results = youtube.commentThreads().list(
                part="snippet",
                videoId=video_id,
                order="relevance",
                textFormat="plainText",
                maxResults=comments_to_fetch
            ).execute()

            # Extract the comment text from each thread
            for item in results["items"]:
                comment = item["snippet"]["topLevelComment"]["snippet"]["textDisplay"]
                comments.append(emoji_pattern.sub("", comment))

            # first fill with NA's
            row = [team_name] + [video_id] + [None] * (comments_to_fetch - 2)
            # then fill with comments
            row[2:len(comments)] = comments
            df.loc[len(df)] = row

            print(f'Fetched {len(comments)} comments for {len(df)} video')
        except:
            print("Video id corrupted.")


if single_channel:
    df.drop('team_name', axis=1, inplace=True)
    
df.to_csv('comments.csv', index=False)